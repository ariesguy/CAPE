=======
License
=======

Cuckoo Sandbox license is shipped with Cuckoo and contained in the "LICENSE"
file inside the "docs" folder.

==========
Disclaimer
==========

Cuckoo is distributed as it is, in the hope that it will be useful, but without
any warranty neither the implied merchantability or fitness for a particular
purpose.

Whatever you do with this tool is uniquely your own responsibility.

=================
Cuckoo Foundation
=================

The `Cuckoo Foundation`_ is a non-profit organization incorporated as a
Stichting in the Netherlands and it's mainly dedicated to support of the
development and growth of Cuckoo Sandbox, an open source malware analysis
system, and the surrounding projects and initiatives.

The Foundation operates to secure financial and infrastructure support to our
software projects and coordinates the development and contributions from the
community.

.. _`Cuckoo Foundation`: http://www.cuckoofoundation.org
