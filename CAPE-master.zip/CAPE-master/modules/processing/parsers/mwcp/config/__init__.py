"""Stores default configuration values."""

import os


log_config = os.path.join(os.path.dirname(__file__), 'log_config.yml')
